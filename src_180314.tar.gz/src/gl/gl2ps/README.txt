This is GL2PS, an OpenGL to PostScript (and PDF, and SVG...) printing
library.

GL2PS is available at http://geuz.org/gl2ps/ and is released under
the GNU Library General Public License (see COPYING.LGPL). GL2PS can also
be used under an alternative license that allows (amongst other things, and
under certain conditions) for static linking with closed-source software
(see COPYING.GL2PS).

Examples are provided in the gl2psTestSimple.c and gl2psTest.c
files. See the documentation for further information.
