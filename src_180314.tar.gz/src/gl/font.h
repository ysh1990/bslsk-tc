void gl_StrokeCharacter( int character );
void gl_StrokeString( const char *string );
float gl_StrokeWidth( int character );
float gl_StrokeLength( const char *string );
GLfloat gl_StrokeHeight( );
