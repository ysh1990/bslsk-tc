// Generic predictor/corrector time-integration

//#define DBG_PC

#include "utils.h"

// Required from solver
// fields updated by time-integration
extern scalar * evolving;
// how to compute updates
double (* update) (scalar * evolving, scalar * updates, double dtmax) = NULL;

// User-provided functions
// gradient
double (* gradient)  (double, double, double) = minmod2;

// the timestep
double dt = 0.;

trace
static void advance_generic (scalar * output, scalar * input, scalar * updates,
			     double dt)
{
  if (input != output)
    trash (output);
  foreach() {
    scalar o, i, u;
    for (o,i,u in output,input,updates)
      o[] = i[] + dt*u[];
  }
  boundary (output);
}

static void (* advance) (scalar * output, scalar * input, scalar * updates,
			 double dt) = advance_generic;

event defaults (i = 0)
{
  // limiting
  for (scalar s in all)
    s.gradient = gradient;
}

//int DBG_AD = 1;

trace
void run()
{
  t = 0., iter = 0; // common.h: current step.
  init_grid (N);

  // main loop
  perf.nc = perf.tnc = 0;
  perf.gt = timer_start();
// see common.h: timers

  while (events (true)) {
    // list of updates, {h,u,cc}->{dh,dhu,dhcc} ??
    scalar * updates = list_clone (evolving);

		/*	FILE * dbg_upfp2 = NULL;
			char name3[10];
			sprintf(name3, "up2dbg_%d.dat", iter);
			dbg_upfp2 = fopen(name3, "w");
			output_field (updates, dbg_upfp2);
			fclose(dbg_upfp2);
			dbg_upfp2 = NULL;
	//DBG_AD = 1;
			FILE * dbg_fp = NULL;
			char name[10];
			sprintf(name, "dbg_%d.dat", iter);
			dbg_fp = fopen(name, "w");
			output_field (evolving, dbg_fp);
			fclose(dbg_fp);
			dbg_fp = NULL;
*/
    dt = dtnext (update (evolving, updates, DT));
	// PAT: update does nothing to dt but updates the value of dtmax; 
	// then dtmax  


/*			FILE * dbg_upfp = NULL;
			char name2[10];
			sprintf(name2, "updbg_%d.dat", iter);
			dbg_upfp = fopen(name2, "w");
			output_field (updates, dbg_upfp);
			fclose(dbg_upfp);
			dbg_upfp = NULL;
			*/
	// YSH dbg
	//fprintf(stderr, "t = %g, dt = %g, i = %d\n", t, dt, iter);
    
	// See Liang, 2009, C&F, Adaptive quadtree...
	if (gradient != zero) {
      /* 2nd-order time-integration */
      scalar * predictor = list_clone (evolving);
      /* predictor */
      advance (predictor, evolving, updates, dt/2.);
      /* corrector */

      update (predictor, updates, dt);
      //update (evolving, updates, dt);
      
      delete (predictor);
      free (predictor);
    }
	

    advance (evolving, evolving, updates, dt);
	// updates change here ??
		/*	FILE * dbg_fp = NULL;
			char name[10];
			sprintf(name, "2dbg_%d.dat", iter);
			dbg_fp = fopen(name, "w");
			output_field (evolving, dbg_fp);
			fclose(dbg_fp);
			dbg_fp = NULL;*/
	//if (DBG_AD)
	{
			//fprintf(stderr, "output: dbg_ad2!\n");

			//DBG_AD = 0;
	}
    delete (updates);
    free (updates);
    update_perf();
    iter = inext, t = tnext;
  }
  timer_print (perf.gt, iter, perf.tnc);
/*
#ifdef DBG_PC
  {
  FILE * dbg_fp = NULL;
  char name[10];
  sprintf(name, "%d_%g.dat", iter, t);
  dbg_fp = fopen(name, "w");
  output_field({*evolving, *predictor, *updates}, dbg_fp, linear = true);
  fclose(dbg_fp);
  dbg_fp = NULL;
  }
  if(iter==3)
#undef DBG_PC
#endif
*/
  free_grid();
}
