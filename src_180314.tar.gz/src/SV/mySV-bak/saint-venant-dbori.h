/**
# A solver for the Saint-Venant equations

The
[Saint-Venant equations](http://en.wikipedia.org/wiki/Shallow_water_equations)
can be written in integral form as the hyperbolic system of
conservation laws
$$
  \partial_t \int_{\Omega} \mathbf{q} d \Omega =
  \int_{\partial \Omega} \mathbf{f} (
  \mathbf{q}) \cdot \mathbf{n}d \partial
  \Omega - \int_{\Omega} hg \nabla z_b
$$
where $\Omega$ is a given subset of space, $\partial \Omega$ its boundary and
$\mathbf{n}$ the unit normal vector on this boundary. For
conservation of mass and momentum in the shallow-water context, $\Omega$ is a
subset of bidimensional space and $\mathbf{q}$ and
$\mathbf{f}$ are written
$$
  \mathbf{q} = \left(\begin{array}{c}
    h\\
    hu_x\\
    hu_y
  \end{array}\right), 
  \;\;\;\;\;\;
  \mathbf{f} (\mathbf{q}) = \left(\begin{array}{cc}
    hu_x & hu_y\\
    hu_x^2 + \frac{1}{2} gh^2 & hu_xu_y\\
    hu_xu_y & hu_y^2 + \frac{1}{2} gh^2
  \end{array}\right)
$$
where $\mathbf{u}$ is the velocity vector, $h$ the water depth and
$z_b$ the height of the topography. See also [Popinet, 
2011](/src/references.bib#popinet2011) for a more detailed
introduction.

## User variables and parameters

The primary fields are the water depth $h$, the bathymetry $z_b$ and
the flow speed $\mathbf{u}$. $\eta$ is the water level i.e. $z_b +
h$. Note that the order of the declarations is important as $z_b$
needs to be refined before $h$ and $h$ before $\eta$. */

//#define MANNING_N 0.05

// cc added by YSH
scalar zb[], h[], eta[], cc[];
vector u[];

/**
The only physical parameter is the acceleration of gravity *G*. Cells are 
considered "dry" when the water depth is less than the *dry* parameter (this 
should not require tweaking). */

double G = 9.81;
double dry = 1e-10;
double MANNING_N = 0.05;

/**
## Time-integration

### Setup

Time integration will be done with a generic
[predictor-corrector](predictor-corrector.h) scheme. */

#include "predictor-corrector.h"

/**
The generic time-integration scheme in predictor-corrector.h needs
to know which fields are updated. */

// cc added by YSH
scalar * evolving = {h, u, cc, zb};

/**
We need to overload the default *advance* function of the
predictor-corrector scheme, because the evolving variables ($h$ and
$\mathbf{u}$) are not the conserved variables $h$ and
$h\mathbf{u}$. */

trace
static void advance_saint_venant (scalar * output, scalar * input, 
				  scalar * updates, double dt)
{

  // recover scalar and vector fields from lists
  scalar hi = input[0], ho = output[0], dh = updates[0];
  vector ui = vector(input[1]), uo = vector(output[1]), dhu = vector(updates[1]);

  // cc added by YSH
  scalar cci = input[3], cco = output[3], dhcc = updates[3];
  
  // zb added by YSH
  scalar zbi = input[4], zbo = output[4], dzb = updates[4];

  // new fields in ho[], uo[]
  foreach() {
    double hold = hi[];
    ho[] = hold + dt*dh[];
	zbo[] = zbi[] + dt*dzb[];
    eta[] = ho[] + zbo[];
    if (ho[] > dry)
	{
      foreach_dimension() {
			  uo.x[] = (hold*ui.x[] + dt*dhu.x[])/ho[];
			  //assert(abs(uo.x[]-ui.x[])<1.);
	  }
	  cco[] = (hold*cci[] + dt*dhcc[])/ho[];// YSH
	  cco[] = min(cco[],1.);
	  cco[] = max(cco[],0.);
	}
    else
	{
      foreach_dimension()
			  uo.x[] = 0.;
	  cco[] = 0.;// YSH
	}
  }
  boundary ({ho, eta, uo, cco,zbo});
}

/**
When using an adaptive discretisation (i.e. a quadtree)., we need
to make sure that $\eta$ is maintained as $z_b + h$ whenever cells are
refined or coarsened. */

#if QUADTREE
static void refine_eta (Point point, scalar eta)
{
  foreach_child()
    eta[] = zb[] + h[];
}

static void coarsen_eta (Point point, scalar eta)
{
  eta[] = zb[] + h[];
}
#endif

/**
### Computing fluxes

Various approximate Riemann solvers are defined in [riemann.h](). */

#include "riemann.h"

trace
double update_saint_venant (scalar * evolving, scalar * updates, double dtmax)
{

  /**
  We first recover the currently evolving fields (as set by the
  predictor-corrector scheme). */

		
  scalar h = evolving[0];
  vector u = vector(evolving[1]);
  scalar cc = evolving[3];// YSH
  scalar zb = evolving[4];// YSH


  /**
  *Fh* and *Fq* will contain the fluxes for $h$ and $h\mathbf{u}$
  respectively and *S* is necessary to store the asymmetric topographic
  source term. */

  face vector Fh[], S[];
  tensor Fq[];

  // Fcc added by YSH
  face vector Fcc[];

  /**
  The gradients are stored in locally-allocated fields. First-order
  reconstruction is used for the gradient fields. */


  // gc[] added by YSH
  vector gh[], geta[], gc[];
  tensor gu[];
  for (scalar s in {gh, geta, gu, gc}) {
    s.gradient = zero; // see common.h.  zero=(0,0,0)
    #if QUADTREE
      s.prolongation = refine_linear;
    #endif
  }
  gradients ({h, eta, u, cc}, {gh, geta, gu, gc});

  /**
  The faces which are "wet" on at least one side are traversed. */

  foreach_face (reduction (min:dtmax)) {
    double hi = h[], hn = h[-1,0];
    if (hi > dry || hn > dry) {

      /**
      #### Left/right state reconstruction
      
      The gradients computed above are used to reconstruct the left
      and right states of the primary fields $h$, $\mathbf{u}$,
      $z_b$. The "interface" topography $z_{lr}$ is reconstructed
      using the hydrostatic reconstruction of [Audusse et al,
      2004](/src/references.bib#audusse2004) */
      
      double dx = Delta/2.;
      double zi = eta[] - hi;
      double zl = zi - dx*(geta.x[] - gh.x[]);
      double zn = eta[-1,0] - hn;
      double zr = zn + dx*(geta.x[-1,0] - gh.x[-1,0]);
      double zlr = max(zl, zr);
      
      double hl = hi - dx*gh.x[];
      double up = u.x[] - dx*gu.x.x[];
      double hp = max(0., hl + zl - zlr);
      
      double hr = hn + dx*gh.x[-1,0];
      double um = u.x[-1,0] + dx*gu.x.x[-1,0];
      double hm = max(0., hr + zr - zlr);

      /**
      #### Riemann solver
      
      We can now call one of the approximate Riemann solvers to get
      the fluxes. */

      double fh, fu, fv;
      //kurganov (hm, hp, um, up, Delta*cm[]/fm.x[], &fh, &fu, &dtmax);
      hllc (hm, hp, um, up, Delta*cm[]/fm.x[], &fh, &fu, &dtmax);
      fv = (fh > 0. ? u.y[-1,0] + dx*gu.y.x[-1,0] : u.y[] - dx*gu.y.x[])*fh;

	  // cc!!! together with fv cal. by simple version of HLLC, see Toro P182 formula(10.28)
	  // fcc added by YSH
	  double fcc;
	  fcc = (fh > 0. ? cc[-1,0] + dx*gc.x[-1,0] : cc[] - dx*gc.x[])*fh;
      
      /**
      #### Topographic source term
      
      In the case of adaptive refinement, care must be taken to ensure
      well-balancing at coarse/fine faces (see [notes/balanced.tm]()). */

      #if QUADTREE
      if (is_prolongation(cell)) {
	hi = coarse(h,0,0);
	zi = coarse(zb,0,0);
      }
      if (is_prolongation(neighbor(-1,0))) {
	hn = coarse(h,-1,0);
	zn = coarse(zb,-1,0);
      }
      #endif
	
      double sl = G/2.*(sq(hp) - sq(hl) + (hl + hi)*(zi - zl));
      double sr = G/2.*(sq(hm) - sq(hr) + (hr + hn)*(zn - zr));
      
      /**
      #### Flux update */
      
      Fh.x[]   = fm.x[]*fh;
      Fq.x.x[] = fm.x[]*(fu - sl);
      S.x[]    = fm.x[]*(fu - sr);
      Fq.y.x[] = fm.x[]*fv;

	  Fcc.x[] = fm.x[]*fcc;// YSH


    }
    else // dry
      Fh.x[] = Fq.x.x[] = S.x[] = Fq.y.x[] = Fcc.x[] = 0.;// YSH Fcc
  }

  boundary_flux ({Fh, S, Fq, Fcc});

  /**
  #### Updates for evolving quantities
  
  We store the divergence of the fluxes in the update fields. Note that
  these are updates for $h$ and $h\mathbf{u}$ (not $\mathbf{u}$). */
  
  scalar dh = updates[0];
  vector dhu = vector(updates[1]);

  scalar dhcc = updates[3]; // YSH
  scalar dzb = updates[4]; // YSH


	//const
	double Ero=0; // erosion
	double Dep=0; // deposition
	double por0=1; // porosity near bed
	double gama0=1; // coef in turbulance term
	double carmen=1; // carmen const
	double uu_star=1; // u_star for shear
	double w_s=1; // settling velocity
	double dia=1; // diameter of the sediment

	double rho_l=1000.; // liquid
	double rho_s=1900.; // solid

	double ddcc=0.;


	vector hu_temp[];

  foreach() {


// explicit sources.

#define RHO (rho_l*(1.-cc[])+rho_s*cc[])
#define RHO0 (rho_l*por0+rho_s*(1.-por0))

	//double dry_manning = 1.e-6; // -10 to -3 improve converence a little
	double manning;
	if (h[]>dry&&h[1,0]>dry&&h[-1,0]>dry) {
			manning = G*sq(MANNING_N)*sqrt(sq(u.x[])+sq(u.y[])) / pow(h[],(1./3.));
	}

	else {
			manning = 0.;
	}
	dzb[] = 0.;//-(Ero-Dep)/(1-por0)/cm[];
	dh[] = 0.;//(Ero-Dep)/(1-por0)/cm[];
	foreach_dimension() {
			dhu.x[] = -manning*u.x[]/cm[];
			//ddcc = h[]>dry ? gc.x[] : 0.;
			//dhu.x[] += -ddcc*(rho_s-rho_l)/2./RHO*G*h[]*h[]/cm[]; // cc
			//dhu.x[] += -(RHO0-RHO)/RHO*(Ero-Dep)/(1-por0)*u.x[]/cm[]; // ED
			
			
			/*
			hu_temp.x[] = h[]*u.x[] + dtmax*dhu.x[];
			assert(hu_temp.x[]*u.x[]>=0.);
	*/
	
	}
	dhcc[] = 0.;//(Ero-Dep)/cm[];





    dh[] += (Fh.x[] + Fh.y[] - Fh.x[1,0] - Fh.y[0,1])/(cm[]*Delta);
    foreach_dimension()
      dhu.x[] += (Fq.x.x[] + Fq.x.y[] - S.x[1,0] - Fq.x.y[0,1])/(cm[]*Delta);

	dhcc[] += (Fcc.x[] + Fcc.y[] - Fcc.x[1,0] - Fcc.y[0,1])/(cm[]*Delta);//YSH
    
	double dmdl = (fm.x[1,0] - fm.x[])/(cm[]*Delta);
    double dmdt = (fm.y[0,1] - fm.y[])/(cm[]*Delta);
    double fG = u.y[]*dmdl - u.x[]*dmdt;
    dhu.x[] += h[]*(G*h[]/2.*dmdl + fG*u.y[]);
    dhu.y[] += h[]*(G*h[]/2.*dmdt - fG*u.x[]);
  }

  return dtmax;
}

/**
## Initialisation

We use the main time loop (in the predictor-corrector scheme) to setup
the initial defaults. */


// cc added 


event defaults (i = 0)
{

  /**
  We overload the default 'advance' and 'update' functions of the
  predictor-corrector scheme and setup the refinement and coarsening
  methods on quadtrees. */

  advance = advance_saint_venant;
  update = update_saint_venant;
#if QUADTREE
  for (scalar s in {h,zb,u,eta,cc}) {
    s.refine = s.prolongation = refine_linear;
    s.coarsen = coarsen_volume_average;
  }
  eta.refine  = refine_eta;
  eta.coarsen = coarsen_eta;
#endif
}

/**
The event below will happen after all the other initial events to take
into account user-defined field initialisations. */

event init (i = 0)
{
  foreach()
    eta[] = zb[] + h[];
  boundary (all);
}

#include "elevation.h"
