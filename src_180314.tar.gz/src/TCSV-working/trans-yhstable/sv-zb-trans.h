/**
# A solver for the Saint-Venant equations

The
[Saint-Venant equations](http://en.wikipedia.org/wiki/Shallow_water_equations)
can be written in integral form as the hyperbolic system of
conservation laws
$$
  \partial_t \int_{\Omega} \mathbf{q} d \Omega =
  \int_{\partial \Omega} \mathbf{f} (
  \mathbf{q}) \cdot \mathbf{n}d \partial
  \Omega - \int_{\Omega} hg \nabla z_b
$$
where $\Omega$ is a given subset of space, $\partial \Omega$ its boundary and
$\mathbf{n}$ the unit normal vector on this boundary. For
conservation of mass and momentum in the shallow-water context, $\Omega$ is a
subset of bidimensional space and $\mathbf{q}$ and
$\mathbf{f}$ are written
$$
  \mathbf{q} = \left(\begin{array}{c}
    h\\
    hu_x\\
    hu_y
  \end{array}\right), 
  \;\;\;\;\;\;
  \mathbf{f} (\mathbf{q}) = \left(\begin{array}{cc}
    hu_x & hu_y\\
    hu_x^2 + \frac{1}{2} gh^2 & hu_xu_y\\
    hu_xu_y & hu_y^2 + \frac{1}{2} gh^2
  \end{array}\right)
$$
where $\mathbf{u}$ is the velocity vector, $h$ the water depth and
$z_b$ the height of the topography. See also [Popinet, 
2011](/src/references.bib#popinet2011) for a more detailed
introduction.

## User variables and parameters

The primary fields are the water depth $h$, the bathymetry $z_b$ and
the flow speed $\mathbf{u}$. $\eta$ is the water level i.e. $z_b +
h$. Note that the order of the declarations is important as $z_b$
needs to be refined before $h$ and $h$ before $\eta$. */

//#define IFWET (h[]>dry && h[-1,0]>dry && h[1,0]>dry)
#define IFWET (h[]>dry)

#define M0 10.

#define SOURCE_ON 1
#define BED_ON 1

#define NOSE 0 

// cc added by YSH
scalar zb[], h[], eta[], cc[], zb0[];
vector u[];

scalar Ero[], Dep[], Phi_b[];
scalar Ri[]; // Richardson number
/**
The only physical parameter is the acceleration of gravity *G*. Cells are 
considered "dry" when the water depth is less than the *dry* parameter (this 
should not require tweaking). */

double G = 9.81;//1.;
double dry = 1e-10;
double p_0 = 0.5;
double rho_w = 1000;
double rho_s = 2650;
double Czf = 0.005; // bed drag coefficient
double rho_0;
double d_s = 77.4e-6; // diameter of sediment
double niu = 1e-6;
double r_w = 0.43;//0.43;//0.43; // upper resistance to bed
double psy = 1.; // calibration parameter for Ero in Parker's formula
double r_b = 2.0;
double c_fh = 1.95;

int dbg_out = 0;
// for dbg, see line 360

int count_up = 0;

/**
## Time-integration

### Setup

Time integration will be done with a generic
[predictor-corrector](predictor-corrector.h) scheme. */

#include "TCSV-working/pc-zb.h"
//#include "predictor-corrector.h"

/**
The generic time-integration scheme in predictor-corrector.h needs
to know which fields are updated. */

// cc added by YSH
scalar * evolving = {h, cc, u};
vector gh[];

/**
We need to overload the default *advance* function of the
predictor-corrector scheme, because the evolving variables ($h$ and
$\mathbf{u}$) are not the conserved variables $h$ and
$h\mathbf{u}$. */


trace static void advance_zb (scalar s, double dt)
{ 
		foreach() {
#if BED_ON
				//s[] = M0-(M0-s[])-Phi_b[]/(1-p_0)*dt;
//#elif
				s[] = s[];
#endif
				//s[] = M0-((M0-s[]));
				//s[] = max(s[],0.);
				;
		}
				
		boundary({s});
		//foreach() 
		//		assert(s[]>=zb0[]);
}



trace
static void advance_saint_venant (scalar * output, scalar * input, 
				  scalar * updates, double dt)
{

  // recover scalar and vector fields from lists
  scalar hi = input[0], ho = output[0], dh = updates[0];

  // cc added by YSH
  scalar cci = input[1], cco = output[1], dhcc = updates[1];

  vector ui = vector(input[2]), uo = vector(output[2]), dhu = vector(updates[2]);

  int EXT=0;
  

  // new fields in ho[], uo[]
  foreach() {

			if(cci[]<0) {
			fprintf (stderr, "cci out of range!!: t=%g dt=%g x=%g y=%g cci=%g hi=%g ui=%g cco=%g ho=%g uo=%g dh=%g dhu=%g dhc=%g\n\n", t, dt, x, y, cci[], hi[], ui.x[], cco[], ho[], uo.x[], dh[], dhu.x[], dhcc[]);
			exit(0);
			}

    double hold = hi[];
    ho[] = hold + dt*dh[];
    eta[] = ho[] + zb[];
    if (ho[] > dry)
	{
      foreach_dimension()
			  uo.x[] = (hold*ui.x[] + dt*dhu.x[])/ho[];
	  //cco[] = abs((hold*cci[] + dt*dhcc[])/ho[]);// YSH
	  //cco[] = (hold*cci[] + dt*dhcc[])/ho[];// YSH
	  cco[] = max((hold*cci[] + dt*dhcc[])/ho[],0);// YSH
	if (cci[]<0)
			fprintf(stderr, "x=%g y=%g cci=%g\n", x, y, cci[]);
	}
    else
	{
      foreach_dimension()
			  uo.x[] = 0.;
	  cco[] = 0.;// YSH
	}
	//assert(ho[]>=0.);
	if (ho[]<0) {
			ho[]=0;
			fprintf(stderr, "h<0!! at x=%g y=%g t=%g dt=%g hi=%g ho=%g dh=%g ux=%g uy=%g Ri=%g\n", x, y, t, dt, hi[], ho[], dh[], u.x[], u.y[], Ri[]);
			//exit(0);
	}

	//if(t!=0)
	//foreach()
			if(cco[]*(cco[]-1.)>0) {
			fprintf (stderr, "cco out of range!!: t=%g dt=%g x=%g y=%g cci=%g hi=%g ui=%g cco=%g ho=%g uo=%g dh=%g dhu=%g dhc=%g Delta=%g \n\n", t, dt, x, y, cci[], hi[], ui.x[], cco[], ho[], uo.x[], dh[], dhu.x[], dhcc[], Delta);
			//exit(0);
			EXT=1;
	}
	//assert (cco[]*(1.-cco[])<=0.);
  }
  boundary ({ho, eta, uo, cco});
  if (EXT) {
		  FILE * fp_adv=fopen ("error.dat","w");
		  output_field ({cci, cco, hi, ho, ui, uo}, fp_adv);
		  fclose(fp_adv);
		  fp_adv = NULL;
		  exit(0);
  }

  //fprintf (stderr, "end adv sv at t= %g\n",t);


}

/**
When using an adaptive discretisation (i.e. a quadtree)., we need
to make sure that $\eta$ is maintained as $z_b + h$ whenever cells are
refined or coarsened. */

#if QUADTREE
static void refine_eta (Point point, scalar eta)
{
  foreach_child()
    eta[] = zb[] + h[];
}

static void coarsen_eta (Point point, scalar eta)
{
  eta[] = zb[] + h[];
}
#endif

/**
### Computing fluxes

Various approximate Riemann solvers are defined in [riemann.h](). */

//#include "riemann.h"
#include "riemann-c.h"
// speed of sound modified, with concentration trans considered.


trace
double update_saint_venant (scalar * evolving, scalar * updates, double dtmax)
{

  /**
  We first recover the currently evolving fields (as set by the
  predictor-corrector scheme). */
		

  //fprintf (stderr, "start update sv at t= %g\n",t);

  scalar h = evolving[0];
  scalar cc = evolving[1];// YSH
  vector u = vector(evolving[2]);


  /**
  *Fh* and *Fq* will contain the fluxes for $h$ and $h\mathbf{u}$
  respectively and *S* is necessary to store the asymmetric topographic
  source term. */

  face vector Fh[], S[];
  tensor Fq[];

  // Fcc added by YSH
  face vector Fcc[];

  /**
  The gradients are stored in locally-allocated fields. First-order
  reconstruction is used for the gradient fields. */


  // gc[] added by YSH
  vector geta[], gc[];
  tensor gu[];
  for (scalar s in {gh, geta, gu, gc}) {
    s.gradient = zero;
    #if QUADTREE
      s.prolongation = refine_linear;
    #endif
  }
  gradients ({h, eta, u, cc}, {gh, geta, gu, gc});

  /**
  The faces which are "wet" on at least one side are traversed. */

  foreach_face (reduction (min:dtmax)) {
    double hi = h[], hn = h[-1,0];
    if (hi > dry || hn > dry) {

      /**
      #### Left/right state reconstruction
      
      The gradients computed above are used to reconstruct the left
      and right states of the primary fields $h$, $\mathbf{u}$,
      $z_b$. The "interface" topography $z_{lr}$ is reconstructed
      using the hydrostatic reconstruction of [Audusse et al,
      2004](/src/references.bib#audusse2004) */
      
      double dx = Delta/2.;
      double zi = eta[] - hi;
      double zl = zi - dx*(geta.x[] - gh.x[]);
      double zn = eta[-1,0] - hn;
      double zr = zn + dx*(geta.x[-1,0] - gh.x[-1,0]);
      double zlr = max(zl, zr);
      
      double hl = hi - dx*gh.x[];
      double up = u.x[] - dx*gu.x.x[];
      double hp = max(0., hl + zl - zlr);
      
      double hr = hn + dx*gh.x[-1,0];
      double um = u.x[-1,0] + dx*gu.x.x[-1,0];
      double hm = max(0., hr + zr - zlr);


	  //fprintf(stderr, "!!!x=%g y=%g %g %g %g %g %g %g %g %g %g\n", x,y, h[-1,0], h[], cc[-1,0], cc[], cc[1,0], gc.x[-1,0], gc.x[], gc.x[1,0], dx);

	  double ccm = cc[-1,0] + dx*gc.x[-1,0];
	  //ccm = x<=0 ? cc[] : ccm;
	  double ccp = cc[] - dx*gc.x[];
	  double cc0 = 0.451; // rho_w/(rho_s-rho_w)
	  // added to solve the Reimann Problem with concentrantion trans.

	  // g'=Rgc, here we use explicit scheme to cal. g'_r (Gm) and g'_l (Gp) as the input to the Reimann solver.
	  double Gm = G * ccm * (rho_s-rho_w) / rho_w;
	  double Gp = G * ccp * (rho_s-rho_w) / rho_w;
	  double Gi = G * cc[] * (rho_s-rho_w) / rho_w;
	  double Gn = G * cc[-1,0] * (rho_s-rho_w) / rho_w;
	  /*
	  double Gm = G * ccm * (rho_s-rho_w) / ((rho_s-rho_w)*ccm+rho_w);
	  double Gp = G * ccp * (rho_s-rho_w) / ((rho_s-rho_w)*ccp+rho_w);
	  double Gi = G * cc[] * (rho_s-rho_w) / ((rho_s-rho_w)*cc[]+rho_w);
	  double Gn = G * cc[-1,0] * (rho_s-rho_w) / ((rho_s-rho_w)*cc[-1,0]+rho_w);
*/
      /**
      #### Riemann solver
      
      We can now call one of the approximate Riemann solvers to get
      the fluxes. */

      double fh, fu, fv, fcc;
	  //int DBG = (t==0.001 ? 1 : 0); // if t=25 or 100, then DBG = 1, otherwise 0.
	  //fprintf(stderr, "t=%g\n", t);

	  //kurganov_c (hm, hp, um, up, Gm, Gp, Delta*cm[]/fm.x[], &fh, &fu, &dtmax);
      int RIE = hllc_cr (x,y,hm, hp, um, up, Gm, Gp, Delta*cm[]/fm.x[], &fh, &fu, &dtmax);
      //int RIE = hllc_cr_new (x,y,hm, hp, um, up, ccm, ccp, Gm, Gp, Delta*cm[]/fm.x[], &fh, &fu, &fcc, &dtmax);
      //hllc_cv0 (hm, hp, um, up, ccm, ccp, cc0, Delta*cm[]/fm.x[], &fh, &fu, &dtmax);
	  // see Riemann-c.h, ccm, ccp, cc0 added.


	  if (!RIE) fprintf (stderr, "x=%g y=%g t=%g c=%g c[-1]=%g c[-0.5-]=%g c[-0.5+]=%g gc[-1]=%g gc[]=%g\n", x, y, t, cc[], cc[-1,0], ccm, ccp, gc.x[-1,0], gc.x[]);


	  
	  fv = (fh > 0. ? u.y[-1,0] + dx*gu.y.x[-1,0] : u.y[] - dx*gu.y.x[])*fh;
	  
	  fcc = (fh > 0. ? cc[-1,0] + dx*gc.x[-1,0] : cc[] - dx*gc.x[])*fh;

      
      /**
      #### Topographic source term
      
      In the case of adaptive refinement, care must be taken to ensure
      well-balancing at coarse/fine faces (see [notes/balanced.tm]()). */

      #if QUADTREE
      if (is_prolongation(cell)) {
	hi = coarse(h,0,0);
	zi = coarse(zb,0,0);
      }
      if (is_prolongation(neighbor(-1,0))) {
	hn = coarse(h,-1,0);
	zn = coarse(zb,-1,0);
      }
      #endif
	
      double sl = 1./2.*(Gp*sq(hp) - Gp*sq(hl) + (Gp*hl + Gi*hi)*(zi - zl));
      double sr = 1./2.*(Gm*sq(hm) - Gm*sq(hr) + (Gm*hr + Gn*hn)*(zn - zr));

      /**
      #### Flux update */
      
      Fh.x[]   = fm.x[]*fh;
      Fq.x.x[] = fm.x[]*(fu - sl);
      S.x[]    = fm.x[]*(fu - sr);
      Fq.y.x[] = fm.x[]*fv;

	  Fcc.x[] = fm.x[]*fcc;// YSH


    }
    else // dry
      Fh.x[] = Fq.x.x[] = S.x[] = Fq.y.x[] = Fcc.x[] = 0.;// YSH
  }

  boundary_flux ({Fh, S, Fq, Fcc});

  /**
  #### Updates for evolving quantities
  
  We store the divergence of the fluxes in the update fields. Note that
  these are updates for $h$ and $h\mathbf{u}$ (not $\mathbf{u}$). */
  
  scalar dh = updates[0];
  scalar dhcc = updates[1];//YSH
  vector dhu = vector(updates[2]);



		  //FILE * out_updates = NULL;
		  //char name_up[10];
		  //sprintf(name_up, "updates_%d.dat", count_up);
		  //out_updates = fopen(name_up, "w");
		  //output_field ({dh,dhu,dhcc}, out_updates);
		  //fclose(out_updates);
		  //out_updates = NULL;
		  //count_up++;

		  foreach() 
		  {
				  dh[] = (Fh.x[] + Fh.y[] - Fh.x[1,0] - Fh.y[0,1])/(cm[]*Delta);
	// h += dh*dt/dx+Sh*dt, so dh = h(i-0.5)-h(i+0.5), Sh = +(ero-dep)


    foreach_dimension()
      dhu.x[] = (Fq.x.x[] + Fq.x.y[] - S.x[1,0] - Fq.x.y[0,1])/(cm[]*Delta);

	dhcc[] = (Fcc.x[] + Fcc.y[] - Fcc.x[1,0] - Fcc.y[0,1])/(cm[]*Delta);//YSH

	//fprintf(stderr, "%g %g %g %g %g %g\n", x, y, dh[], dhu.x[], dhu.y[], dhcc[]);


/*
    double dmdl = (fm.x[1,0] - fm.x[])/(cm[]*Delta);
    double dmdt = (fm.y[0,1] - fm.y[])/(cm[]*Delta);
    double fG = u.y[]*dmdl - u.x[]*dmdt;
    dhu.x[] += h[]*(G*h[]/2.*dmdl + fG*u.y[]);
    dhu.y[] += h[]*(G*h[]/2.*dmdt - fG*u.x[]);*/
	
  }
		  //output_field ({dh,dhu,dhcc,Fh,S,Fcc,Fq.x,Fq.y});//, out_updates);
		  //fclose(out_updates);
		  //out_updates = NULL;
		  //count_up++;
		  boundary ({dh, dhu, dhcc});

  fprintf (stderr, "end update sv at t= %g\n",t);
  return dtmax;
}




trace
double update_saint_venant_source (scalar * evolving, scalar * updates, double dt)
{

  /**
  We first recover the currently evolving fields (as set by the
  predictor-corrector scheme). */
		

  scalar h = evolving[0];
  scalar cc = evolving[1];// YSH
  vector u = vector(evolving[2]);


  /**
  #### Updates for evolving quantities
  
  We store the divergence of the fluxes in the update fields. Note that
  these are updates for $h$ and $h\mathbf{u}$ (not $\mathbf{u}$). */
  
  scalar dh = updates[0];
  scalar dhcc = updates[1];//YSH
  vector dhu = vector(updates[2]);



  stats ghx = statsf(gh.x);
  stats ghy = statsf(gh.y);


  scalar SSu[], SSv[], SSc[], SSh[];
  scalar U_m[]; // full speed of current

  scalar rho[];
  scalar omega_w[]; // sediment settling velocity
  //double omega_w = sqrt(sq(13.95*niu/d_s)+1.09*(rho_s/rho_w-1)*G*d_s)-13.95*niu/d_s;

  rho_0 = rho_w*p_0+rho_s*(1-p_0);

  foreach() {		  
		  
		  rho[] = rho_w*(1.-cc[])+rho_s*cc[];
		  omega_w[] = sqrt(sq(13.95*niu/d_s)+1.09*(rho_s/rho_w-1)*G*d_s)-13.95*niu/d_s;
		  //omega_w[] = sqrt(sq(13.95*niu/d_s)+1.09*(rho_s/rho[]-1)*G*d_s)-13.95*niu/d_s;
		  U_m[] = sqrt(u.x[]*u.x[]+u.y[]*u.y[]);

		  Ri[] = (U_m[]!=0.) ? (rho_s-rho_w)/rho_w*cc[]*G*h[]/U_m[]/U_m[] : HUGE;
		  //Ri[] = (U_m[]!=0.) ? (rho_s-rho_w)/rho[]*cc[]*G*h[]/U_m[]/U_m[] : HUGE;
  }
  boundary ({rho, omega_w, U_m, Ri});
/*		  
		  if (dbg_out<=4)  
		  {	  
				  FILE * ch_fp = NULL;
				  char name0[10];
				  sprintf(name0, "ch_%d_%g.log", dbg_out, t);
				  ch_fp = fopen(name0, "w");
				  //fprintf (ch_fp, "%g %g %g %g %g %g %g %g %g %g %g\n", x, y, SSu[], SSv[], rho[], cc[], omega_w[], u.x[], u.y[], U_m[], Ri[]);
				  //output_field ( {rho, cc, omega_w, u.x, u.y, U_m, Ri}, ch_fp, linear = true);
				  output_field ( {rho, cc, omega_w, u, U_m, Ri}, ch_fp);
				  fclose(ch_fp);
				  ch_fp = NULL;
				  dbg_out++;
		  }// dbg checking water entrainment in equ.(h).
*/

#define HPED 1

#if (HPED==0)
  scalar zeta[], P_z[], Gama_phi[];
  foreach() {
		  zeta[] = U_m[]==0 ? -HUGE : omega_w[]/0.4/sqrt(Czf)/U_m[]; // 0.4 for karmen const
		  P_z[] = U_m[]==0 ? 1. : (zeta[]<pow(2.,(-10.)) ? 1. : exp(pow((0.12*log(zeta[])/log(2.)+1.2),4.)));
		  Gama_phi[] = r_b*cc[]*h[]*P_z[];
  }
#endif


		  foreach() {
#if HPED

//Ero and Dep
		  if (h[]>5.*d_s) {

		  Ero[] = U_m[]==0 ? 0. : (omega_w[]*psy*1.3*pow(10., (-7))* pow(U_m[]/omega_w[]*sqrt(Czf/niu*d_s*sqrt(G*d_s*(rho_s-rho_w)/rho_w)),5.) / (1+4.3*pow(10., (-7))* pow(U_m[]/omega_w[]*sqrt(Czf/niu*d_s*sqrt(G*d_s*(rho_s-rho_w)/rho_w)),5.)));
		  //Ero[] =(omega_w[]*psy*1.3*pow(10., (-7))* pow(U_m[]/omega_w[]*sqrt(Czf/niu*d_s*sqrt(G*d_s*(rho_s-rho_w)/rho[])),5.) / (1+4.3*pow(10., (-7))* pow(U_m[]/omega_w[]*sqrt(Czf/niu*d_s*sqrt(G*d_s*(rho_s-rho_w)/rho[])),5.)));

		  //Dep[] = (U_m[]!=0) ? omega_w[]*cc[]*(1+31.5*pow(omega_w[]/(U_m[]*sqrt(Czf)),1.46)) : 0.;

		  //Ero[] = 0.;
		  //Dep[] = IFWET ? 1.6*cc[]*omega_w[] : 0.;//0.;//h[]>dry ? cc[] : 0.;//0.006*cc[];
		  //Dep[] = 2.*cc[]*omega_w[];//0.;//h[]>dry ? cc[] : 0.;//0.006*cc[];
		  Dep[] = r_b*cc[]*omega_w[];//0.;//h[]>dry ? cc[] : 0.;//0.006*cc[];
		  //Ero[] = /*U_m[]==0 ? 0. :*/ min ((zb[]-zb0[])/dt*(1-p_0)+Dep[], Ero[]);


	  }
		  else
		  {
				  Ero[] = 0.;
				  Dep[] = 0.;
		  }
//Ero and Dep

#else
		  Dep[] = cc[]*h[]==0 ? 0. : max(omega_w[]*r_b*cc[]*(1-Gama_phi[]/cc[]/h[]), 0.);
		  Ero[] = U_m[]==0 ? 0. : (omega_w[]*psy*1.3*pow(10., (-7))* pow(U_m[]/omega_w[]*sqrt(Czf/niu*d_s*sqrt(G*d_s*(rho_s-rho_w)/rho_w)),5.) / (1+4.3*pow(10., (-7))* pow(U_m[]/omega_w[]*sqrt(Czf/niu*d_s*sqrt(G*d_s*(rho_s-rho_w)/rho_w)),5.)));
		  Ero[] = min ((1-p_0)/dt*(double)(zb[]-zb0[])+(double)Dep[], Ero[]);
#endif
// kubo,2004





		  //Ero[] = 0.;// for dep-jump

		  Phi_b[] = Ero[]-Dep[];
		  //Phi_b[] = 0;
		  // for hydrojump of conservative TC

		  //Phi_b[] = max (Phi_b[], (M0-(M0-zb[]))*(1-p_0)/dt);//zb>=0. alternative.

		  
		  SSu[] = -Czf*U_m[]*u.x[]*(1+r_w);
		  SSv[] = -Czf*U_m[]*u.y[]*(1+r_w); //fric in hu

		  //SSu[] += (rho[]-rho_w)/rho[]*u.x[]*U_m[]*0.00153/(0.0204+Ri[]);
		  //SSv[] += (rho[]-rho_w)/rho[]*u.y[]*U_m[]*0.00153/(0.0204+Ri[]);
		  //entrainment in hu
		  
		  SSu[] += (rho[]-rho_w)/rho_w*u.x[]*U_m[]*0.00153/(0.0204+Ri[]);
		  SSv[] += (rho[]-rho_w)/rho_w*u.y[]*U_m[]*0.00153/(0.0204+Ri[]);
		  
		  //Phi_b[] = max(Phi_b[], (-h[]/dt)*(1-p_0));//h equ.
		  //assert(h[]+Phi_b[]/(1-p_0)*dt>=-(1.e-16));

		 //if(h[]*cc[]+Phi_b[]*dt<0.) {
		  if(0) {
				  //fprintf(stderr, "x=%g y=%g h=%g cc=%g ux=%g uy=%g Phi=%g dt=%g t=%g phi*dt=%g\n", x, y, h[], cc[], u.x[], u.y[], Phi_b[], dt, t, Phi_b[]*dt);
				  Phi_b[] = max(Phi_b[], -h[]*cc[]/dt);
		  Phi_b[] = max(Phi_b[], (-h[]/dt)*(1-p_0));//h equ.
		  }

		  SSc[] = Phi_b[];  

		  if (0)
		  //fprintf(stderr, "dt=%g t=%g x=%g y=%g fricx=%g fricy=%g Ero=%g Dep=%g h=%g cc=%g ux=%g uy=%g omega=%g zeta=%g P_z=%g Gama_phi=%g ch=%g  U_m =%g Ri= %g\n", dt, t, x, y, SSu[], SSv[], Ero[], Dep[], h[], cc[], u.x[], u.y[], omega_w[],zeta[], P_z[],Gama_phi[], cc[]*h[],U_m[], Ri[]);
		  fprintf(stderr, "dt=%g t=%g x=%g y=%g fricx=%g fricy=%g Ero=%g Dep=%g h=%g cc=%g ux=%g uy=%g omega=%g U_m =%g Ri= %g\n", dt, t, x, y, SSu[], SSv[], Ero[], Dep[], h[], cc[], u.x[], u.y[], omega_w[],U_m[], Ri[]);


		 
		  SSu[] += u.x[]*Phi_b[]*(rho[]-rho_0)/rho[]/(1-p_0);
		  SSv[] += u.y[]*Phi_b[]*(rho[]-rho_0)/rho[]/(1-p_0);
		  // Erosion and Deposition
		

#define NIU 0
#if NIU

		  /*
		  vector gPux[], gPvy[], gPPux[], gPPvy[];
		  gradients ({u.x, u.y},{gPux, gPvy});
		  gradients ({gPux.x, gPvy.y},{gPPux, gPPvy});

		  SSu[] += niu*(gPPux.x[]+gPPvy.y[]);
		  SSv[] += niu*(gPPux.x[]+gPPvy.y[]);

		  */


		  SSu[] += niu*(u.x[-1,0]-2.*u.x[]+u.x[1,0])/sq(Delta);
		  SSv[] += niu*(u.y[-1,0]-2.*u.y[]+u.y[1,0])/sq(Delta);
#endif
//kubo2004 u damping to match the x_N-t curves


#if NOSE


		  //SSu[] += x>0.5 ? -c_fh*rho_w/rho[]*U_m[]*u.x[]*(h[])/(x-0.5) : 0.;
		/*  if (gh.x[]==ghx.min) {
		  SSu[] += gh.x[]==ghx.min ? -c_fh*rho_w/rho[]*U_m[]*u.x[]*abs(gh.x[]) : 0.;
		  fprintf (stderr, "!!!! t=%g x=%g y=%g ghxmin=%g\n\n",t, x, y, ghx.min);}
		  if (gh.y[]==ghy.min) {
		  SSv[] += gh.y[]==ghy.min ? -c_fh*rho_w/rho[]*U_m[]*u.y[]*abs(gh.y[]) : 0.;}*/
		  //SSv[] += gh.x[]<0 ? -c_fh*rho_w/rho[]*U_m[]*u.y[]*(h[])/y : 0.;
		  //SSu[] += gh.x[]<0 ? -c_fh*rho_w/rho[]*U_m[]*u.x[]*2*tanh(gh.x[]/5.) :0.;
		  SSu[] += gh.x[]<0 ? -c_fh*rho_w/rho[]*U_m[]*u.x[]*abs(gh.x[]) : 0.;
		  SSv[] += gh.y[]<0 ? -c_fh*rho_w/rho[]*U_m[]*u.y[]*abs(gh.y[]) : 0.;
#endif






		  //SSh[] = ((/*IFWET &&*/ U_m[]!=0.) ? 0.00153/(0.0204+Ri[])*U_m[]) + (Ero[]-Dep[])/(1-p_0) : 0.;
		  SSh[] = (0.00153/(0.0204+Ri[])*U_m[])+Phi_b[]/(1-p_0);
		  //SSh[] = Phi_b[]/(1-p_0);
		  // E, D and water entrainment for h
		  }

		  boundary ({Ero, Dep, SSu, SSv, SSh, SSc,Phi_b});

		  //FILE * out_updates = NULL;
		  //char name_up[10];
		  //sprintf(name_up, "updates_%d.dat", count_up);
		  //out_updates = fopen(name_up, "w");
		  //output_field ({dh,dhu,dhcc}, out_updates);
		  //fclose(out_updates);
		  //out_updates = NULL;
		  //count_up++;

		  foreach() 
		  {

	//fprintf(stderr, "%g %g %g %g %g %g\n", x, y, dh[], dhu.x[], dhu.y[], dhcc[]);


#if SOURCE_ON
	/*dh[] += SSh[];
	dhu.x[] += SSu[];
	dhu.y[] += SSv[];
	dhcc[] += SSc[];*/
	dh[] = SSh[];
	dhu.x[] = SSu[];
	dhu.y[] = SSv[];
	dhcc[] = SSc[];
#else
	dh[] = 0.;
	dhu.x[] = 0.;
	dhu.y[] = 0.;
	dhcc[] = 0.;

#endif

/*
    double dmdl = (fm.x[1,0] - fm.x[])/(cm[]*Delta);
    double dmdt = (fm.y[0,1] - fm.y[])/(cm[]*Delta);
    double fG = u.y[]*dmdl - u.x[]*dmdt;
    dhu.x[] += h[]*(G*h[]/2.*dmdl + fG*u.y[]);
    dhu.y[] += h[]*(G*h[]/2.*dmdt - fG*u.x[]);*/
	// Coriolis force
  }
		  //output_field ({dh,dhu,dhcc,Fh,S,Fcc,Fq.x,Fq.y});//, out_updates);
		  //fclose(out_updates);
		  //out_updates = NULL;
		  //count_up++;
		  boundary ({dh, dhu, dhcc});


  fprintf (stderr, "end update source_sv at t= %g\n",t);
  return dt;
}

/**
## Initialisation

We use the main time loop (in the predictor-corrector scheme) to setup
the initial defaults. */

event defaults (i = 0)
{

  /**
  We overload the default 'advance' and 'update' functions of the
  predictor-corrector scheme and setup the refinement and coarsening
  methods on quadtrees. */

  advance = advance_saint_venant;
  update = update_saint_venant;
  update_source = update_saint_venant_source;
#if QUADTREE
  for (scalar s in {h,zb,u,eta,cc/*,Phi_b,Ero,Dep,Ri,SSu,SSv,rho,SSh,SSc,U_m,omega_w*/}) {
    s.refine = s.prolongation = refine_linear;
    s.coarsen = coarsen_volume_average;
  }
  eta.refine  = refine_eta;
  eta.coarsen = coarsen_eta;
#endif
}

/**
The event below will happen after all the other initial events to take
into account user-defined field initialisations. */

event init (i = 0)
{
  foreach()
    eta[] = zb[] + h[];
  boundary (all);
}

#include "elevation.h"
