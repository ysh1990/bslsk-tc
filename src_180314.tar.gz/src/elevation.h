/**
# Conservation of water surface elevation 

When using the default adaptive reconstruction of variables, the
[Saint-Venant solver](saint-venant.h) will conserve the water depth
when cells are refined or coarsened. However, this will not
necessarily ensure that the "lake-at-rest" condition (i.e. a constant
water surface elevation) is also preserved. In what follows, we
redefine the *refine()* and *coarsen()* methods of the water depth $h$
so that the water surface elevation $\eta$ is conserved.

We start with the reconstruction of fine "wet" cells: */


#define DBG_ELE 0


#if TREE
static void refine_elevation (Point point, scalar h)
{
  // reconstruction of fine cells using elevation (rather than water depth)
  // (default refinement conserves mass but not lake-at-rest)
  if (h[] >= dry) {


#if DBG_ELE
	  if (h[]>1000)
			  fprintf(stderr, "!! in refinement wet before: h too large at wet point!! t=%g, x=%g, y=%g, zb=%g, h=%g, eta=%g, level=%d\n", t,x,y,zb[],h[],zb[]+h[],level);
#endif



    double eta = zb[] + h[];   // water surface elevation  
    coord g; // gradient of eta
    if (gradient) {
      foreach_dimension()
	g.x = gradient (zb[-1] + h[-1], eta, zb[1] + h[1])/4.;
#if 0//DBG_ELE
	  fprintf (stderr, "\n refine_elevation_wet: t=%g,gradient!=0, g.x=%g, g.y=%g, zb[-1,0]=%g, zb[1,0]=%g, h[-1,0]=%g, h[1,0]=%g, zb[0,-1]=%g, zb[0,1]=%g, h[0,1]=%g, h[0,-1]=%g, eta=%g, zb=%g, h=%g\n",t,g.x,g.y,zb[-1,0],zb[1,0],h[-1,0],h[1,0],zb[0,-1],zb[0,1],h[0,-1],h[0,1],eta,zb[],h[]);
#endif
	}
    else
      foreach_dimension()
	g.x = (zb[1] - zb[-1])/(2.*Delta);
    // reconstruct water depth h from eta and zb
    foreach_child() {
      double etac = eta;
      foreach_dimension()
	etac += g.x*child.x;
      h[] = max(0, etac - zb[]);

#if DBG_ELE
	  if (h[]>1000)
			  fprintf(stderr, "!! in refinement wet after: h too large at wet point!! t=%g, x=%g, y=%g, etac=%g,eta=%g, g.x=%g, g.y=%g, child.y=, child.x=, zb=%g, h=%g,level=%d\n", t,x,y,etac,eta,g.x,g.y,/*child.y,child.x,*/zb[],h[],level);
#endif
    }
  }
  else {

    /**
    The "dry" case is a bit more complicated. We look in a 3x3
    neighborhood of the coarse parent cell and compute a depth-weighted
    average of the "wet" surface elevation $\eta$. We need to do this
    because we cannot assume a priori that the surrounding wet cells are
    necessarily close to e.g. $\eta = 0$. */


#if DBG_ELE
	  if (h[]>1000)
			  fprintf(stderr, "!! in refinement dry before: h too large at wet point!! t=%g, x=%g, y=%g, zb=%g, h=%g, eta=%g\n", t,x,y,zb[],h[],zb[]+h[]);
#endif




    double v = 0., eta = 0.; // water surface elevation
    // 3x3 neighbourhood
    foreach_neighbor(1)
      if (h[] >= dry) {
	eta += h[]*(zb[] + h[]);
	v += h[];
/*
#if DBG_ELE
	fprintf (stderr, "\ndbg_refine_elevation_dry: t=%g, x=%g, y=%g, h[]=%g, eta[]=%g, zb[]=%g, eta=%g, v=%g\n\n",t, x,y,h[],h[]+zb[],zb[],eta,v);
#endif*/
	  }
    if (v > 0.)
      eta /= v; // volume-averaged eta of neighbouring wet cells
    else

      /**
      If none of the surrounding cells is wet, we assume a default sealevel
      at zero. */

      //eta = 0.; 
      eta = zb[]; // original eta=0

    /**
    We then reconstruct the water depth in each child using $\eta$ (of the
    parent cell i.e. a first-order interpolation in contrast to the wet
    case above) and $z_b$ of the child cells. */
    
    // reconstruct water depth h from eta and zb
    foreach_child() {
      h[] = max(0, eta - zb[]);
#if DBG_ELE
	  if (h[]>1000) 
			  fprintf(stderr, "!! in refinement dry after: h too large at dry point!! t=%g, x=%g, y=%g, h=%g, eta=%g, zb=%g\n", t,x,y,h[],eta,zb[]);
#endif
	}
  }
}

/**
Cell coarsening is simpler. We first compute the depth-weighted
average of $\eta$ over all the children... */

static void coarsen_elevation (Point point, scalar h)
{
  double eta = 0., v = 0.;
  foreach_child() 
  {
    if (h[] > dry) 
	{
      eta += h[]*(zb[] + h[]);
      v += h[];


#if DBG_ELE
	  if (h[]>1000)
			  fprintf (stderr, "!! in coarsening wet before: h too large at wet point!! t=%g, x=%g,y=%g,h=%g, eta=%g, v=%g, zb=%g\n",t,x,y,h[],eta,v, zb[]);
#endif




/*
#if DBG_ELE
	  fprintf (stderr, "\ndbg_coarsen_elevation_wet: t=%g, x=%g,y=%g,h=%g, eta=%g, v=%g, zb=%g\n",t,x,y,h[],eta,v, zb[]);
#endif*/
    }
#if DBG_ELE
	else if (h[]<=dry)
	  fprintf (stderr, "end dry: t=%g, x=%g,y=%g,h=%g, eta=%g, v=%g, zb=%g\n",t,x,y,h[],eta,v, zb[]);
  fprintf (stderr, "end child: t=%g, x=%g,y=%g,h=%g, eta=%g, v=%g, zb=%g\n",t,x,y,h[],eta,v, zb[]);
#endif
  }
  /*
  if (h[]<=dry) 
  {
	  eta = zb[];
	  //fprintf (stderr, "!!Warning: eta default \nt=%g, x=%g,y=%g,h=%g, eta=%g, v=%g, zb=%g\n",t,x,y,h[],eta,v, zb[]);
  }*/
  // h[] < dry?

  /**
  ... and use this in combination with $z_b$ (of the coarse cell) to
  compute the water depth $h$.  */
    
  if (v > 0.)
    h[] = max(0., eta/v - zb[]);
  else // dry cell
    h[] = 0.;
#if DBG_ELE
	  if (h[]>1000) 
	  {
			  fprintf(stderr, "!! in coarsening after: h too large!! t=%g, x=%g, y=%g,eta=%g,v=%g,zb=%g,h=%g\n", t,x,y,eta,v,zb[],h[]);
			  //h[] = 0.;
			   foreach_neighbor(1)
					   fprintf(stderr, "at (%g,%g), h=%g, v=%g, eta=%g, zb=%g\n", x, y, h[], v, eta, zb[]);
	  }
	  fprintf(stderr, "\n\n");
#endif
}

/**
We also need to define a consistent prolongation function. For cells
which are entirely surrounded by wet cells, we can use the standard
linear refinement function, otherwise we use straight injection from
the parent cell. */

static void prolongation_elevation (Point point, scalar h)
{
  bool wet = true;
  foreach_neighbor(1)
    if (h[] <= dry)
      wet = false, break;
  if (wet)
    refine_bilinear (point, h);
  else {
    double hc = h[], zc = zb[];
    foreach_child() {
      h[] = hc;
      zb[] = zc;
    }
  }
#if DBG_ELE
	  if (h[]>1000)
			  fprintf(stderr, "!! in prolongation: h too large!! t=%g, x=%g, y=%g, h=%g\n", t,x,y,h[]);
#endif
}

/**
Finally we define a function which will be called by the user to apply
these reconstructions.  */

void conserve_elevation (void)
{
  h.refine  = refine_elevation;
  h.prolongation = prolongation_elevation;
  h.coarsen = coarsen_elevation;
}
#else // Cartesian
void conserve_elevation (void) {}
#endif

/**
# "Radiation" boundary conditions

This can be used to implement open boundary conditions at low
[Froude numbers](http://en.wikipedia.org/wiki/Froude_number). The idea
is to set the velocity normal to the boundary so that the water level
relaxes towards its desired value (*ref*). */

#define radiation(ref) (sqrt (G*max(h[],0.)) - sqrt(G*max((ref) - zb[], 0.)))

/**
# Tide gauges

An array of *Gauge* structures passed to *output_gauges()* will create
a file (called *name*) for each gauge. Each time *output_gauges()* is
called a line will be appended to the file. The line contains the time
and the value of each scalar in *list* in the (wet) cell containing
*(x,y)*. The *desc* field can be filled with a longer description of
the gauge. */

typedef struct {
  char * name;
  double x, y;
  char * desc;
  FILE * fp;
} Gauge;

void output_gauges (Gauge * gauges, scalar * list)
{
  scalar * list1 = list_append (NULL, h);
  for (scalar s in list)
    list1 = list_append (list1, s);

  int n = 0;
  for (Gauge * g = gauges; g->name; g++, n++);
  coord a[n];
  n = 0;
  for (Gauge * g = gauges; g->name; g++, n++) {
    double xp = g->x, yp = g->y;
    unmap (&xp, &yp);
    a[n].x = xp, a[n].y = yp;
  }
  int len = list_len(list1);
  double v[n*len];
  interpolate_array (list1, a, n, v, false);

  if (pid() == 0) {
    n = 0;
    for (Gauge * g = gauges; g->name; g++) {
      if (!g->fp) {
	g->fp = fopen (g->name, "w");
	if (g->desc)
	  fprintf (g->fp, "%s\n", g->desc);
      }
      if (v[n] != nodata && v[n] > dry) {
	fprintf (g->fp, "%g", t);
	n++;
	for (scalar s in list)
	  fprintf (g->fp, " %g", v[n++]);
	fputc ('\n', g->fp);
	fflush (g->fp);
      }
      else
	n += len;
    }
  }

  free (list1);
}
