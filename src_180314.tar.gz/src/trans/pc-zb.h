// Generic predictor/corrector time-integration

//#define DBG_PC

#include "utils.h"

// Required from solver
// fields updated by time-integration
extern scalar * evolving;
// how to compute updates
double (* update) (scalar * evolving, scalar * updates, double dtmax) = NULL;

// User-provided functions
// gradient
double (* gradient)  (double, double, double) = minmod2;

// the timestep
double dt = 0.;

trace
static void advance_generic (scalar * output, scalar * input, scalar * updates,
			     double dt)
{
  if (input != output)
    trash (output);
  foreach() {
    scalar o, i, u;
    for (o,i,u in output,input,updates)
      o[] = i[] + dt*u[];
  }
  boundary (output);
}

static void (* advance) (scalar * output, scalar * input, scalar * updates,
			 double dt) = advance_generic;

event defaults (i = 0)
{
  // limiting
  for (scalar s in all)
    s.gradient = gradient;
}

static void advance_zb (scalar s, double dt);

trace
void run()
{
  t = 0., iter = 0;
  init_grid (N);

  // main loop
  perf.nc = perf.tnc = 0;
  perf.gt = timer_start();
  while (events (true)) {
    // list of updates
    scalar * updates = list_clone (evolving);
    dt = dtnext (update (evolving, updates, DT));
	// PAT: update does nothing to dt but updates the value of dtmax; 
	// then dtmax  


	// YSH dbg
	//fprintf(stderr, "t = %g, dt = %g, i = %d\n", t, dt, iter);
    
	if (gradient != zero) {
      /* 2nd-order time-integration */
      scalar * predictor = list_clone (evolving);
      /* predictor */
      advance (predictor, evolving, updates, dt/2.);
      /* corrector */
      update (predictor, updates, dt);
      delete (predictor);
      free (predictor);
    }
    advance (evolving, evolving, updates, dt);
	advance_zb (zb, dt);
    delete (updates);
    free (updates);
    update_perf();
    iter = inext, t = tnext;
  }
  timer_print (perf.gt, iter, perf.tnc);
/*
#ifdef DBG_PC
  {
  FILE * dbg_fp = NULL;
  char name[10];
  sprintf(name, "%d_%g.dat", iter, t);
  dbg_fp = fopen(name, "w");
  output_field({*evolving, *predictor, *updates}, dbg_fp, linear = true);
  fclose(dbg_fp);
  dbg_fp = NULL;
  }
  if(iter==3)
#undef DBG_PC
#endif
*/
  free_grid();
}
