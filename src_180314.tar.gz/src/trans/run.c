/**
  This is the stable version solving TC(Hu's model) for checking the Well-balanced Property,
  and note that HC and HU are not properly cal.ed when ADP==1.
  the Dep is set to be 0 and the Riemann solver is hllc-cr in riemann-c.h.
  The equa. of zb[] has not been considered.
**/

#include "SV/CaoHu/riemann-mod/SV-C_decp-nos-v3.h"

#define LEVEL 9
#define ADP 1
#define L 2.136
#define BF(x,y) (((x<0.306)&&(y>0.019)) || ((x>0.306)&&((y-0.019)>0.178/1.83*(x-0.306))))
//#define BF(x,y) (y>0.197)
// boundary function (BOOL), if BF==true, then out of the domain.

bid solid_bound;

u.n[solid_bound] = dirichlet(0.);
u.t[solid_bound] = dirichlet(0.);


u.t[left] = dirichlet(0.);
u.n[left] = dirichlet(0.);
u.n[right] = neumann(0.);

/**
u.n[bottom] = neumann(0.);
u.t[bottom] = neumann(0.);
cc[bottom] = neumann(0.);
h[bottom] = neumann(0.);
**/

int main()
{
		size (L);
		G = 9.81;
		CFL = 0.3;
		init_grid (1<<LEVEL);
		run();
}


event init (i = 0)
{
		DT = 1e-2;
		mask (BF(x,y) ? solid_bound : none);

				FILE * bound_fp = NULL;
				char name_b[10];
				sprintf (name_b, "bound.dat");
				bound_fp = fopen (name_b, "w");
		foreach()
		{
				//zb[] = 0.24*exp(-50.*sq(x-4.0));
				zb[] = 0.;
				//h[] = x<=1 ? 0.15: 0.;//max(dry, 0.15-zb[]);
				h[] = x<0.153 ? 0.14 : 0.;
				u.x[] = 0.;
				u.y[] = 0.;
				cc[] = 0.019;

				fprintf(bound_fp, "%g %g %d\n", x, y, BF(x,y));
		}
		fclose (bound_fp);
		bound_fp = NULL;
}

event test(t = 0; t += 1) // note "t = t0" must be added or there will be some unknown mistake.
{
		stats check_ux = statsf(u.x);
		stats check_h = statsf(h);
		stats check_c = statsf(cc);
		stats check_zb = statsf(zb);
		fprintf(stderr, "t = %g, dt = %g, CFL = %g, minux = %g, maxux =  %g, minh = %g, maxh = %g, minc = %g, maxc = %g, minzb = %g, maxzb = %g\n", t, dt, CFL, check_ux.min, check_ux.max, check_h.min, check_h.max, check_c.min, check_c.max, check_zb.min, check_zb.max);
		//assert (abs(check_ux.max)<0.1);

		//if(!((t-25)*(t-100))) // note the priosity of "()" and "!"
		//if(!((t-1)*(t-2)*(t-3)*(t-4)*(t-5)*(t-6))) // note the priosity of "()" and "!"
		{
				FILE * out_fp = NULL;
				char name[10];
				sprintf (name, "%g.dat", t);
				out_fp = fopen (name, "w");
				fprintf(stderr, "output: t = %g, i = %d, dt = %g\n", t, i, dt);
				
				scalar HU[], HC[];
				scalar Bound[];
				foreach()
						Bound[] = 1-BF(x,y);

#if ADP
				fprintf (stderr, "ADP is used!\n");
				output_field ({zb, h, eta, cc, u.x, Bound}, out_fp, linear = true);
#else
				fprintf (stderr, "ADP is not used!\n");
				foreach() {
						HU[] = h[] * u.x[];
						HC[] = h[] * cc[];
				}
				output_field ({zb, h, eta, cc, HU, HC, u.x, Bound}, out_fp);
#endif
// PAT: For post-prossessing, the lines wheres Bound!=1 should be blanked out; other methods like '+30e' are improper.

				fclose (out_fp);
				out_fp = NULL;
		}
}

//event endtime (t = 105) {return 1;}
event endtime (t = 11) {return 1;}

#if ADP
event adapt (i++) {
		astats s = adapt_wavelet ({h, u.x}, (double[]){1e-1, 1e-4}, LEVEL);
//		fprintf (ferr, "t = %g, # refined %d cells, coarsened %d cells\n", t, s.nf, s.nc);
}
#endif


