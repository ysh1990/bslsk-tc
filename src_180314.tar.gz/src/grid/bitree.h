#define dimension 1
#define GRIDNAME "Binary-tree"
#include "tree.h"

void bitree_methods() {
  tree_methods();
}
