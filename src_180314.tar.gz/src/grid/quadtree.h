#define dimension 2
#define GRIDNAME "Quadtree"
#include "tree.h"

void quadtree_methods() {
  tree_methods();
}
