/* A collection of Riemann solvers for the Saint-Venant system 
 *
 * References:
 *    [1] Kurganov, A., & Levy, D. (2002). Central-upwind schemes for the
 *    Saint-Venant system. Mathematical Modelling and Numerical
 *    Analysis, 36(3), 397-425.
 */

#define SQRT3 1.73205080756888
#define epsilon 1e-30

void kinetic (double hm, double hp, double um, double up, double Delta,
	      double * fh, double * fq, double * dtmax)
{
  double ci = sqrt(G*hm/2.);
  double Mp = max(um + ci*SQRT3, 0.);
  double Mm = max(um - ci*SQRT3, 0.);
  double cig = ci/(6.*G*SQRT3);
  *fh = cig*3.*(Mp*Mp - Mm*Mm);
  *fq = cig*2.*(Mp*Mp*Mp - Mm*Mm*Mm);
  if (Mp > 0.) {
    double dt = CFL*Delta/Mp;
    if (dt < *dtmax)
      *dtmax = dt;
  }

  ci = sqrt(G*hp/2.);
  Mp = min(up + ci*SQRT3, 0.);
  Mm = min(up - ci*SQRT3, 0.);
  cig = ci/(6.*G*SQRT3);
  *fh += cig*3.*(Mp*Mp - Mm*Mm);
  *fq += cig*2.*(Mp*Mp*Mp - Mm*Mm*Mm);
  if (Mm < - epsilon) {
    double dt = CFL*Delta/-Mm;
    if (dt < *dtmax)
      *dtmax = dt;
  }
}

void kurganov_c (double hm, double hp, double um, double up, double Gm, double Gp, double Delta, double * fh, double * fq, double * dtmax)
{
  double cp = sqrt(Gp*hp), cm = sqrt(Gm*hm);
  double ap = max(up + cp, um + cm); ap = max(ap, 0.);
  double am = min(up - cp, um - cm); am = min(am, 0.);
  double qm = hm*um, qp = hp*up;
  double a = max(ap, -am);
  if (a > epsilon) {
    *fh = (ap*qm - am*qp + ap*am*(hp - hm))/(ap - am); // (4.5) of [1]
    *fq = (ap*(qm*um + Gm*sq(hm)/2.) - am*(qp*up + Gp*sq(hp)/2.) + ap*am*(qp - qm))/(ap - am);
    double dt = CFL*Delta/a;
    if (dt < *dtmax)
      *dtmax = dt;
  }
  else
    *fh = *fq = 0.;
}

void hllc (double hm, double hp, double um, double up, double Delta,
	   double * fh, double * fq, double * dtmax)
{
  double cm = sqrt (G*hm), cp = sqrt (G*hp);
  double ustar = (um + up)/2. + cm - cp;
  double cstar = (cm + cp)/2. + (um - up)/4.;
  double SL = hm == 0. ? up - 2.*cp : min (um - cm, ustar - cstar);
  double SR = hp == 0. ? um + 2.*cm : max (up + cp, ustar + cstar);

  if (0. <= SL) {
    *fh = um*hm;
    *fq = hm*(um*um + G*hm/2.);
  }
  else if (0. >= SR) {
    *fh = up*hp;
    *fq = hp*(up*up + G*hp/2.);
  }
  else {
    double fhm = um*hm;
    double fum = hm*(um*um + G*hm/2.);
    double fhp = up*hp;
    double fup = hp*(up*up + G*hp/2.);
    *fh = (SR*fhm - SL*fhp + SL*SR*(hp - hm))/(SR - SL);
    *fq = (SR*fum - SL*fup + SL*SR*(hp*up - hm*um))/(SR - SL);
  }

  double a = max(fabs(SL), fabs(SR));
  if (a > epsilon) {
    double dt = CFL*Delta/a;
    if (dt < *dtmax)
      *dtmax = dt;
  }
}


// !!PAT!!
// hllc_c solvers are wrong because the g' is wrong.
// a new and right solver is hllc_cr


//void hllc_cv0 (double hm, double hp, double um, double up, double Delta,
//	   double * fh, double * fq, double * dtmax)
void hllc_cv0 (double hm, double hp, double um, double up, double ccm, double ccp, double cc0, double Delta,
	   double * fh, double * fq, double * dtmax) // m for left, p for right, cc for concentration, cc0 is a const
{
  double cm = sqrt (ccm/(ccm+cc0)*G*hm), cp = sqrt (ccp/(ccp+cc0)*G*hp);
  double ustar = (um + up)/2. + cm - cp;
  double cstar = (cm + cp)/2. + (um - up)/4.;
  double SL = hm == 0. ? up - 2.*cp : min (um - cm, ustar - cstar);
  double SR = hp == 0. ? um + 2.*cm : max (up + cp, ustar + cstar);

  if (0. <= SL) {
    *fh = um*hm;
    *fq = hm*(um*um + ccm/(ccm+cc0)*G*hm/2.);
  }
  else if (0. >= SR) {
    *fh = up*hp;
    *fq = hp*(up*up + ccp/(ccp+cc0)*G*hp/2.);
  }
  else {
    double fhm = um*hm;
    double fum = hm*(um*um + ccm/(ccm+cc0)*G*hm/2.);
    double fhp = up*hp;
    double fup = hp*(up*up + ccp/(ccp+cc0)*G*hp/2.);
    *fh = (SR*fhm - SL*fhp + SL*SR*(hp - hm))/(SR - SL);
    *fq = (SR*fum - SL*fup + SL*SR*(hp*up - hm*um))/(SR - SL);
  }

  double a = max(fabs(SL), fabs(SR));
  if (a > epsilon) {
    double dt = CFL*Delta/a;
    if (dt < *dtmax)
      *dtmax = dt;
  }
}





void hllc_c (double hm, double hp, double um, double up, double ccm, double ccp, double cc0, double Delta,
	   double * fh, double * fq, double * dtmax) // m for left, p for right, cc for concentration, cc0 is a const

/* hllc solver for equ-TC, with concentration trans, where the speed of sound and riemann state should be modified. */

{
		double a0m = (ccm*ccm+0.5*ccm*cc0+0.5*cc0)/(ccm+cc0)/(ccm+cc0);
		double a0p = (ccp*ccp+0.5*ccp*cc0+0.5*cc0)/(ccp+cc0)/(ccm+cc0);

		double cm = sqrt(G*hm*a0m), cp = sqrt(G*hp*a0p); // speed of sound

		
/* what follows needs confirmation. */
  double ustar = (um + up)/2. + cm - cp;
  double cstar = (cm + cp)/2. + (um - up)/4.;
  double SL = hm == 0. ? up - 2.*cp : min (um - cm, ustar - cstar);
  double SR = hp == 0. ? um + 2.*cm : max (up + cp, ustar + cstar);

  if (0. <= SL) {
    *fh = um*hm;
    *fq = hm*(um*um + a0m*G*hm/2.);
  }
  else if (0. >= SR) {
    *fh = up*hp;
    *fq = hp*(up*up + a0p*G*hp/2.);
  } // these are right

  else {
    double fhm = um*hm;
    double fum = hm*(um*um + a0m*G*hm/2.);
    double fhp = up*hp;
    double fup = hp*(up*up + a0p*G*hp/2.);
    *fh = (SR*fhm - SL*fhp + SL*SR*(hp - hm))/(SR - SL);
    *fq = (SR*fum - SL*fup + SL*SR*(hp*up - hm*um))/(SR - SL);
  } // where does these come from? (not found in Toro p181)

  double a = max(fabs(SL), fabs(SR));
  if (a > epsilon) {
    double dt = CFL*Delta/a;
    if (dt < *dtmax)
      *dtmax = dt;
  }
}


// !!PAT!!
// the solvers for TC: hllc-c(v0) are wrong, because of the wrong g'!
// hllc_cr is right


/*void*/int hllc_cr (double x, double y, double hm, double hp, double um, double up, double Gm, double Gp, double Delta,
	   double * fh, double * fq, double * dtmax) // m for left, p for right, cc for concentration
		// This is in fact a HLL solver, together with SV.h: "fv = ..." leads to hllc, see Toro P182 (10.28).
{
		
		//fprintf (stderr, "into hllc_cr\n");
		/**
		assert(Gm>=0);
		assert(hm>=0);
		assert(Gp>=0);
		assert(hp>=0);
**/
		if (Gm<0 || hm<0 || Gp<0 || hp<0) {
				//fprintf(stderr, "!!error!! t=%g, x=%g, y=%g, Gm=%g, Gp=%g, hm=%g, hp=%g\n", t, x, y, Gm, Gp, hm, hp);
				//exit(0);
				return 0;
		}




		double Gm_bak = Gm, Gp_bak = Gp;
  double G_avr = (Gm+Gp)/2;
		//Gm=1./2.*(Gm+Gp);
		//Gp=1./2.*(Gm+Gp);

  double cmm = sqrt (Gm*hm), cp = sqrt (Gp*hp);
  double ustar = (um + up)/2. + cmm - cp;
  double cstar = (cmm + cp)/2. + (um - up)/4.; // See Toro P101, (5.20,21), two rarefaction approximation.

#define ORIRM 1

#if ORIRM

  double SL = hm == 0. ? up - 2.*cp : min (um - cmm, ustar - cstar); // meant to be speed of left shock
  double SR = hp == 0. ? um + 2.*cmm : max (up + cp, ustar + cstar);
// PAT: see Toro P181, not the suggested (10.22), but Toro(1995), JHR, Experimental and numerical assessment of the shallow water model for two dimensional dam break type problems. (18,19,21)
  // see Toro P117, Remark 6.4.2; P113.


#else
  // we test a Toro P181 (10.22),(10.23) with (10.18) and (10.17) here.

  double h_star = 1./2*(hm+hp) - 1./4*(up-um)*(hm+hp)/(cmm+cp); // (10.17) exact depth positivity
  //double h_star = sq(1./2*(cmm+cp)+1./4*(um-up))/G_avr; // (10.18) two-rarefaction

  double SL = hm==0. ? up-2.*cp : um-(h_star>hm ? sqrt(1./2*(h_star+hm)*h_star/hm/hm) : 1)*cmm;
  double SR = hp==0. ? um+2.*cmm : up+(h_star>hp ? sqrt(1./2*(h_star+hp)*h_star/hp/hp) : 1)*cp;
#endif

  if (0. <= SL) {
    *fh = um*hm;
    *fq = hm*(um*um + Gm*hm/2.);
  }
  else if (0. >= SR) {
    *fh = up*hp;
    *fq = hp*(up*up + Gp*hp/2.);
  }
  else {
		  assert(SR-SL);
    double fhm = um*hm;
    double fum = hm*(um*um + Gm*hm/2.);
    double fhp = up*hp;
    double fup = hp*(up*up + Gp*hp/2.);
    *fh = (SR*fhm - SL*fhp + SL*SR*(hp - hm))/(SR - SL);
    *fq = (SR*fum - SL*fup + SL*SR*(hp*up - hm*um))/(SR - SL);
  }

  double a = max(fabs(SL), fabs(SR));

  if (0)
  fprintf (stderr, "t = %g, dt = %g, x=%g, y=%g, a = %g, SL = %g, SR = %g, hm = %g, hp =%g, um = %g, up = %g, cm = %g, cp = %g, ustar = %g, cstar = %g, Gm = %g, Gp =%g \n", t, dt, x,y,a, SL, SR, hm, hp, um, up, cmm, cp, ustar, cstar, Gm, Gp);
// DBG

  //fprintf (stderr, "IN Riemann: t = %g, dt = %g\n, a = %g, epsilon = %g\n", t, dt, a, epsilon);
// DBG

  if (a > epsilon) {
    double dt = CFL*Delta/a;
    if (dt < *dtmax)
      *dtmax = dt;
	//fprintf (stderr, "IN Riemann: t = %g, dt = %g\n", t, dt);
	//DBG
  }

  Gm=Gm_bak;
  Gp=Gp_bak;
  return 1;
}




/*void*/int hllc_cr_new (double x, double y, double hm, double hp, double um, double up, double ccm, double ccp, double Gm, double Gp, double Delta,
	   double * fh, double * fq, double * fcc, double * dtmax) // m for left, p for right, cc for concentration
		// This is in fact a HLL solver, together with SV.h: "fv = ..." leads to hllc, see Toro P182 (10.28).
{
		
		if (Gm<0 || hm<0 || Gp<0 || hp<0) {
				fprintf(stderr, "!!error!! t=%g, x=%g, y=%g, Gm=%g, Gp=%g, hm=%g, hp=%g\n", t, x, y, Gm, Gp, hm, hp);
				//exit(0);
				return 0;
		}


  double cmm = sqrt (Gm*hm), cp = sqrt (Gp*hp);
  double ustar = (um + up)/2. + cmm - cp;
  double cstar = (cmm + cp)/2. + (um - up)/4.; // See Toro P101, (5.20,21), two rarefaction approximation.


  double SL = hm == 0. ? up - 2.*cp : min (um - cmm, ustar - cstar); // meant to be speed of left shock
  double SR = hp == 0. ? um + 2.*cmm : max (up + cp, ustar + cstar);
// PAT: see Toro P181, not the suggested (10.22), but Toro(1995), JHR, Experimental and numerical assessment of the shallow water model for two dimensional dam break type problems. (18,19,21)
  // see Toro P117, Remark 6.4.2; P113.

  double Par_starL = (SL-um)/(SL-ustar);
  double hstarL = hm*Par_starL;
  double ustarL = hm*Par_starL*ustar;
  double ccstarL = hm*Par_starL*ccm;


  double Par_starR = (SR-up)/(SR-ustar);
  double hstarR = hp*Par_starR;
  double ustarR = hp*Par_starR*ustar;
  double ccstarR = hp*Par_starR*ccp;


  if (0. <= SL) {
    *fh = um*hm;
    *fq = hm*(um*um + Gm*hm/2.);
	*fcc = hm*um*ccm;
  }
  else if (0. >= SR) {
    *fh = up*hp;
    *fq = hp*(up*up + Gp*hp/2.);
	*fcc = hp*up*ccp;
  }
  else if (SL<=0. && ustar>=0.) {
		  *fh = um*hm + SL*(hstarL-hm);
		  *fq = hm*(um*um+Gm*hm/2.) + SL*(ustarL-um);
		  *fcc = hm*um*ccm + SL*(ccstarL-ccm);
  }
  else if (ustar<=0. && 0<=SR) {
		  *fh = up*hp + SR*(hstarR-hp);
		  *fq = hp*(up*up+Gp*hp/2.) + SR*(ustarR-up);
		  *fcc = hp*up*ccp + SR*(ccstarR-ccp);
  }
  /*else {
		  assert(SR-SL);
    double fhm = um*hm;
    double fum = hm*(um*um + Gm*hm/2.);
    double fhp = up*hp;
    double fup = hp*(up*up + Gp*hp/2.);
    *fh = (SR*fhm - SL*fhp + SL*SR*(hp - hm))/(SR - SL);
    *fq = (SR*fum - SL*fup + SL*SR*(hp*up - hm*um))/(SR - SL);
  }*/

  double a = max(fabs(SL), fabs(SR));

  if (0)
  fprintf (stderr, "t = %g, dt = %g, x=%g, y=%g, a = %g, SL = %g, SR = %g, hm = %g, hp =%g, um = %g, up = %g, cm = %g, cp = %g, ustar = %g, cstar = %g, Gm = %g, Gp =%g \n", t, dt, x,y,a, SL, SR, hm, hp, um, up, cmm, cp, ustar, cstar, Gm, Gp);
// DBG

  //fprintf (stderr, "IN Riemann: t = %g, dt = %g\n, a = %g, epsilon = %g\n", t, dt, a, epsilon);
// DBG

  if (a > epsilon) {
    double dt = CFL*Delta/a;
    if (dt < *dtmax)
      *dtmax = dt;
	//fprintf (stderr, "IN Riemann: t = %g, dt = %g\n", t, dt);
	//DBG
  }

  return 1;
}
