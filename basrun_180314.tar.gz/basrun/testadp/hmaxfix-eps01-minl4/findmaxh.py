#!/usr/bin/python
 
maxh = []

# input
with open("err.log", "r") as fi:
		lines = fi.readlines()
		for currentline in lines:
				tmpstart = currentline.find('maxh = ')
				tmpend = currentline.find(', minc')

				if tmpstart != -1:
						tmp = currentline[tmpstart+7:tmpend]
						maxh.append(tmp)
		fi.close()

with open("t_maxh.txt", "w") as fo:
		for line in maxh:
				fo.write(line+'\n')
				print line
		fo.close()
#print type(maxh)
