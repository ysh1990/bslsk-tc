#rm adp_dbg
qcc -source -grid=tree -L$BASILISK/kdt run.c -lm -lkdt
gcc -Wall -std=c99 -I$BASILISK -L$BASILISK/kdt -O2 _run.c -o adp_dbg -lm -lkdt "-fno-stack-protector" > compl.log 2>&1

tmp=$(grep 'error' compl.log)

if [ ! -n "$tmp" ]
then
		echo "compl complete!"
else
	echo "tmp=$tmp, compl error!"
fi

