
#read -p 'del bak/ now? [y]/n' judge
#if ["$judge"

if [ ! -d "$bak"]; then
　　mkdir "$bak"
    echo 'create bak/ done!'
else 
    rm -rf "$bak"
    mkdir "$bak"
    echo 'del bak/ and recreate baki/ done!'
fi

mv *.png bak/
mv *.dat bak/
mv out* bak/
mv *.log bak/
mv parameter bak/
mv adp_dbg bak/
mv log* bak/
mv *.gfs bak/
mv *.bin bak/

echo 'mv files to bak/ done!'
