
if [ ! -d "$bak"]; then
		mkdir "$bak"
		echo 'create bak'
else
		rm -rf "$bak"
		mkdir "$bak"
		echo 'recreate bak'
fi

mv *.png bak/
mv *.dat bak/
mv out* bak/
mv *.log bak/
mv parameter bak/
mv adp_dbg bak/
cp run.c bak/
cp compl.sh bak/
