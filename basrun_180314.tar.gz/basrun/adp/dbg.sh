./adp_dbg > err.log 2>&1
