#!/bin/sh

qcc -source -events -grid=tree -L$BASILISK/kdt run.c -lm -lkdt
#gcc -Wall -std=c99 -I$BASILISK -L$BASILISK/kdt -O2 _run.c -o adp_dbg -lm -lkdt "-fno-stack-protector" > compl.log 2>&1
gcc -Wall -std=c99 -I$BASILISK -L$BASILISK/kdt -O0 -g _run.c -o adp_dbg -lm -lkdt "-fno-stack-protector" > compl.log 2>&1

tmp=$(grep 'error' compl.log)
#tmp=$(grep 'z' test)

if [ ! -n "$tmp" ]
then
		echo "\n\n------------compl complete!-----------\n\n"
else
	echo "\n\n-------------tmp=$tmp, compl error!---------------\n\n"
fi

