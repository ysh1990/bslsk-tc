
#read "are you sure to del *.png, *.dat, *.log, parameter, adp_dbg ? y/n"

rm *.png
rm *.dat
rm out* 
rm *.log
rm parameter
rm adp_dbg 
